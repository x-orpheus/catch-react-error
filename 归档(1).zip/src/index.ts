import catchreacterror from './catch-react-error'

export * from './components/Errorboundary'
export * from './interface/propsInterface'

export default catchreacterror
